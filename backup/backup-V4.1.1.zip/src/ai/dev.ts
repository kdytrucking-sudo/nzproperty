import {dev} from 'genkit-cli';

// Note: You must `npm install` any plugins you want to use.
// See the Genkit docs for a list of available plugins:
// https://firebase.google.com/docs/genkit/plugins

// Note: You can uncomment the following line to run the flow server.
// dev({force: true});
