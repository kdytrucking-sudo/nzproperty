// This file has been moved to use-templates.tsx to support JSX.
