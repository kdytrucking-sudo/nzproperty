import type { ExtractPropertyDataOutput } from "@/ai/flows/extract-property-data-from-pdf";

export type PropertyData = ExtractPropertyDataOutput;
