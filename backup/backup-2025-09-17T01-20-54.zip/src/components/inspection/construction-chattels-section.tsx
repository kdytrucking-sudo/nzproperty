// This file is deprecated. Its logic has been split into
// construction-section.tsx and chattels-section.tsx.
// This file is kept to prevent breaking changes but can be removed later.
import * as React from 'react';
export default function DeprecatedConstructionChattelsSection() { return <div />; }
